﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Net;
using System.IO;


namespace WindowsFormsApplication1
{
    public class GetHTML
    {
        
        public GetHTML()
        {
            try
            {
                WebClient myWebClient = new WebClient();
                //获取或设置用于对向Internet资源的请求进行身份验证的网络凭据。
                myWebClient.Credentials = CredentialCache.DefaultCredentials;
                //从指定网站下载数据
                Byte[] pageData = myWebClient.DownloadData("https://list.lu.com/list/p2p");
                string pageHTML = Encoding.UTF8.GetString(pageData);

                StreamWriter sw = new StreamWriter("C:\\Users\\xu\\Desktop\\GetHTMLTest.html");
                sw.Write(pageHTML);
            }
            catch(WebException webEx)
            {
                Console.WriteLine(webEx.Message.ToString());
            }
           /* string pageHTML = "";
            try
            {
                HttpWebRequest request = (HttpWebRequest)WebRequest.Create("https://list.lu.com/list/p2p");
                //设置连接超时时间 
                request.Timeout = 30000;
                request.Headers.Set("Pragma", "no-cache");
                HttpWebResponse response = (HttpWebResponse)request.GetResponse();
                Stream streamReceive = response.GetResponseStream();
                Encoding encoding = Encoding.GetEncoding("UTF8");
                StreamReader streamReader = new StreamReader(streamReceive, encoding);
                pageHTML = streamReader.ReadToEnd();
                StreamWriter sw = new StreamWriter("C:\\Users\\xu\\Desktop\\GetHTMLTest.html");
                sw.Write(pageHTML);
            }
            catch (WebException webEx)
            {
                Console.WriteLine(webEx.Message.ToString());
            }*/
        }

        
    }
}
